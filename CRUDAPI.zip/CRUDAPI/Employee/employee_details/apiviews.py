from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.status import HTTP_200_OK, HTTP_201_CREATED, HTTP_204_NO_CONTENT, HTTP_400_BAD_REQUEST, HTTP_404_NOT_FOUND
from employee_details.models import Employee
from django.conf import settings

session = settings.DB_SESSION

class EmployeeView(APIView):
   def get(self, request):
      data = fetch_data()
      result = logic_on_data(data)
      return Response(result, status=HTTP_200_OK)
   
   def post(self, request):
      data = request.data
      result = insert_data(data)
      if result:
         return Response("Employee created successfully", status=HTTP_201_CREATED)
      else:
         return Response("Bad Request", status=HTTP_400_BAD_REQUEST)

   def put(self, request):
      data = request.data
      emp_id = data.get('id')
      if not emp_id:
         return Response("ID is required for PUT request", status=HTTP_400_BAD_REQUEST)
      
      existing_employee = session.query(Employee).filter_by(id=emp_id).first()
      if existing_employee:
         existing_employee.name = data.get('name', existing_employee.name)
         existing_employee.email = data.get('email', existing_employee.email)
         existing_employee.country = data.get('country', existing_employee.country)
         session.commit()
         return Response("Employee details updated successfully", status=HTTP_200_OK)
      else:
         return Response("Employee not found", status=HTTP_400_BAD_REQUEST)
      
      
   def patch(self, request):
    employee_id = request.data.get('id')
    if not employee_id:
        return Response("Employee ID is required for updating.", status=HTTP_400_BAD_REQUEST)
    
    data = request.data
    if update_employee(employee_id, data):
        return Response("Employee updated successfully." + str(data), status=HTTP_200_OK)
    else:
        return Response("Employee not found.", status=HTTP_404_NOT_FOUND)

   def delete(self, request):
      data = request.data
      emp_id = data.get('id')
      if not emp_id:
         return Response("ID is required for DELETE request", status=HTTP_400_BAD_REQUEST)

      existing_employee = session.query(Employee).filter_by(id=emp_id).first()
      if existing_employee:
         session.delete(existing_employee)
         session.commit()
         return Response("Employee deleted successfully", status=HTTP_204_NO_CONTENT)
      else:
         return Response("Employee not found", status=HTTP_400_BAD_REQUEST)

def logic_on_data(data_list):
   final_list = []
   if data_list:
      for data in data_list:
         single_record = {}
         single_record['id'] = data[0]
         single_record['name'] = data[1]
         single_record['email'] = data[2]
         single_record['country'] = data[3]
         final_list.append(single_record)
      return final_list

def fetch_data():
   result_set = session.query(Employee.id, Employee.name, Employee.email, Employee.country).all()
   return result_set

def insert_data(data):
   
      emp_details = Employee(
         name=data['name'],
         email=data['email'],
         country=data['country']
      )
      session.add(emp_details)
      session.commit()
      return True
  
def update_employee(employee_id, data):
    employee = session.query(Employee).filter_by(id=employee_id).first()
    if employee:
        for key, value in data.items():
            setattr(employee, key, value)
        session.commit()
        return True
    else:
        return False
    







