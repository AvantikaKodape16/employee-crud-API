from django.urls import path
from employee_details.apiviews import EmployeeView
from django.conf import settings

app_name = 'employee_details'

urlpatterns = [
    path('fetch',EmployeeView.as_view(),name='fetch'),
    path('create',EmployeeView.as_view(),name='create'),
    path('update',EmployeeView.as_view(),name='update'),
    path('delete',EmployeeView.as_view(),name='delete'),


]

