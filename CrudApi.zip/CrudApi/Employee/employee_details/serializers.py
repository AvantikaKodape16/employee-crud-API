from rest_framework import serializers
from .models import emp

class Serializer(serializers.ModelSerializer):
    class Meta:
        model = emp
        fields = ['id', 'name', 'lname', 'address']