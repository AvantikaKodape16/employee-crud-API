from django.shortcuts import render
from django.db import models 
from models import emp
from sqlalchemy import create_engine, Column, Integer, String, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import select
from employee_details import config
from sqlalchemy import select
from sqlalchemy.orm import Session
from sqlalchemy.orm import sessionmaker
from django.conf import settings

session = settings.session

# with Session(engine) as session:
#     spongebob = emp(
#         name="spongebob",
#         lname="Spongebob Squarepants",
#         address="Mumbai",
#     )
#     session.add_all([spongebob])
#     session.commit()

## alchemy query
emp_details = emp(
    name="spongebob",
    lname="Spongebob Squarepants",
    address="Mumbai"
)

session.add(emp_details)
session.commit()

#stmt = select(emp).where(emp.name == "sara")

# # from rest_framework import viewsets
# # from .models import emp
# # from .serializers import Serializer


# # class ViewSet(viewsets.ModelViewSet):
# #     queryset = emp.objects.all()
# #     serializer_class = Serializer