from django.urls import path
from . import apiview
from . import views
from django.conf import settings

urlpatterns = [
path('', views.getData),
path('testapi/', views.postData),
]