from django.shortcuts import render
from rest_framework.response import Response
from rest_framework.decorators import api_view

# Create your views here.

@api_view(['GET'])  
def getData(request):
   data = request.query_params
 #url:'http://127.0.0.1:8000/employee_details/?1=HELLO'
   print(data)
   #print("request dir", dir(request))
   return Response("Good morning.")

@api_view(['POST'])
def postData(request):
   data = request.data

   #print(data)
   return Response("msg")

# from rest_framework.views import APIView
# from rest_framework.response import Response

# class Test(APIView):
#     def post(self, request):
#         msg = request.data['good morning']
       
#         return Response(msg)
    