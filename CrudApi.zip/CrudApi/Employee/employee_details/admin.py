# from django.contrib import admin
# from .models import emp
# # Register your models here.

# admin.site.register()    