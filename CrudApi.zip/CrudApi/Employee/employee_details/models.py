from django.db import models
from sqlalchemy import create_engine, Column, Integer, String, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine


Base = declarative_base()

class emp(Base):
    __tablename__ = 'emp'
    id = Column(Integer, primary_key=True)
    name = Column(String(30))
    lastname = Column(String(30))
    address = Column(String(100))